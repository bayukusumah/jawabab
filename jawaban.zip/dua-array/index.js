function duaArray(input,query){
    let hasil =[];
   for(i=0;i<query.length;i++){
    let jumlah=0;
      for(j=0;j<input.length;j++){
          if(query[i]=== input[j]){
             jumlah += 1;
             hasil[i] = jumlah;
          }else{
            jumlah +=0;
             hasil[i] = jumlah;
          }
      } 
   }
   console.log(hasil);
}   
const input =['xc', 'dz', 'bbb', 'dz'];
 const query =['bbb', 'ac', 'dz']; 
duaArray(input,query);