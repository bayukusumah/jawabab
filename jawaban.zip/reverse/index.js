function balik_kata(kata){
    const akhir_kata = kata.substring(kata.length-1);
    const temp = kata.substring(0,5).split("").reverse();
    const hasil = temp.join('');
    console.log(hasil+akhir_kata);
}
balik_kata("NEGIE1");