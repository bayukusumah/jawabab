function cari(data_input){
    const temp = data_input.split(" ");
    let check=[];
    let panjang=0;
    let indexs;
    for(i=0;i<temp.length;i++){
        check[i] = temp[i].length;
    }
    for(j=0;j<check.length;j++){
        if(j===0){
           panjang = check[0];
        }else{
            const tmp = check[j];
            if(panjang < tmp){
                panjang = tmp;
                indexs = j;
            }

        }
    }
    
    console.log(temp[indexs] +": " +panjang +" karater");
}
cari("Kerjakan dengan menggunakan bahasa pemograman yg anda kuasai, buat folder terpisah untuk soal ini");