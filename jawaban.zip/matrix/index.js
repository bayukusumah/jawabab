function matrix_pertama(matrix1){
    let hasil_pertama = 0;
    for(i=0;i<matrix1.length;i++){
        for(j=0;j<matrix1.length;j++){ 
            if(i === j){
                hasil_pertama +=  matrix1[i][j];
            }
        }
    }
   return hasil_pertama;
}
function matrix_kedua(matrix1){
    let hasil_kedua = 0;
    let counter = 0;
    let mundur = matrix1.length-1;
    for(i=0;i<matrix1.length;i++){
        counter = i;
        for(j=0;j<matrix1.length;j++){ 
            if(i==counter && j === mundur){
                hasil_kedua +=  matrix1[i][j];
                mundur -=1;
            }
        }
    }
    return hasil_kedua;
}
function jumlahkan(matrix1,matrix2){
    const hasil = matrix1 - matrix2;
    console.log('hasil pengurangan ' + matrix1 +' - '+ matrix2 +' adalah '+ hasil);
}
const matrix1 =[[1, 2, 0], [4, 5, 6], [7, 8, 9]]; 
//[[5, 2, 0,1], [4, 5, 6,0], [7, 8, 9,3],[3,4,6,9]];
const pertama = matrix_pertama(matrix1);
const kedua = matrix_kedua(matrix1);
jumlahkan(pertama,kedua);