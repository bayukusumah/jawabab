const request = require('supertest');
const express = require('express');

const app = require('../app');

describe('Good user list', function () {
    test('responds to /', async () => {
        const res = await request(app).get('/users');
        expect(res.header['content-type']).toBe('application/json; charset=utf-8');
        expect(res.statusCode).toBe(200);
        //expect(res.text).toEqual('hello world!');
      });
})    