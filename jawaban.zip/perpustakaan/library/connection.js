const mysql = require('mysql');
conn = mysql.createConnection({
    host : 'localhost',
    user : 'root',
    password : '',
    database : 'perpustakaan'
});
conn.connect((err)=>{
  if(err) throw err;
});
exports.databaseConnection = conn;