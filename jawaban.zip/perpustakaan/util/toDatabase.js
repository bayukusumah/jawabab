const {databaseConnection} = require('../library/connection');

exports.InsertPinjam = function(req,res,value,code_book){
    const qry = "INSERT INTO pinjam(code_books,code_members,date,status) VALUES ?";
        databaseConnection.query(qry,[value],(err,result)=>{
            if(err) throw err;
            res.send('code book '+code_book+' has been borrow');
        });
}