const express = require('express');
const dateFormat = require('date-and-time');
const {databaseConnection} = require('../library/connection');
const {InsertPinjam} = require('../util/toDatabase');
const router = express.Router();

/* GET users listing. */
router.get('/', function(req, res, next) {
  const qry = "select * from members";
  databaseConnection.query(qry,(err,result)=>{
    if(err) throw err;
    res.send(result);
  });
});
router.post('/borrow',function(req,res,next){
    const code_book = req.body.code_book;
    const code_member = req.body.code_member;
    const date_borrow = new Date();
    const status = 1;
    const qry_check = "SELECT * FROM pinjam where code_members ='"+code_member+"'";

    databaseConnection.query(qry_check,(err,result)=>{
      if(err) throw err;
     
      if(result.length === 0){
       
        const value = [[code_book,code_member,date_borrow,status]];
        InsertPinjam(req,res,value,code_book);
      }else{
        switch(result[0].status){
          case 0:
            const value = [[code_book,code_member,date_borrow,status]];
            InsertPinjam(req,res,value,code_book);
              break;
          case 1:
              res.send('this '+ code_member+' still borrow book');
              break;
          case 2:
              const date_db = new Date(result[0].date_penalty);
              const new_date = new Date();
              const hasil = dateFormat.format(date_db,"DD/MM/YYYY");
              if(date_db > new_date){
                res.send('you still have penalty date can not borrow book until '+ hasil);
              }else{
                const qry2 = "DELETE FROM pinjam where code_books='"+req.body.code_book+"'";
                databaseConnection.query(qry2,(err,result)=>{
                  if(err) throw err;
                  res.send('your penalty has been remove');
                });
              }   
               break;        
        }
      }
  });

});
router.get('/borrowList',async function(req,res,next){
  const qry_check = "SELECT * from members";
  const qry_book = "select b.title,c.code_members from books b LEFT join pinjam c on b.code = c.code_books";
  let members,book;

  members = await new Promise((resolve) => {
    databaseConnection.query(qry_check,(err,result)=>{
      if(err) throw err;
      resolve(result);
    });
  }).then(temp => {
    return temp;
  });
  book = await new Promise((resolve) => {
    databaseConnection.query(qry_book,(err,result)=>{
      if(err) throw err;
      resolve(result);
    });
  }).then(temp => {
    return temp;
  });
   let hasil=[];
    for(j=0;j<members.length;j++){
        let obj = {};
        obj['code'] = members[j].code;
        obj['name'] = members[j].name;
      for(i=0;i<book.length;i++){
        if(book[i].code_members !== null){
          if(members[j].code === book[i].code_members){
            obj['books'] = book[i];
            break;
          }else{
            obj['books']=[];
          }
        }
      }
    hasil.push(obj);
  }
  res.send(hasil);
});
module.exports = router;
