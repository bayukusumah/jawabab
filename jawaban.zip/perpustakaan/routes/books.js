const express = require('express');
const dateFormat = require('date-and-time');
const {databaseConnection} = require('../library/connection');
const router = express.Router();


router.get('/', function(req,res,next){
    try{
            const qry = "SELECT a.code, a.title,a.author, ( IF(b.status='1',0,a.stock) )"+ 
              " AS stock FROM books as a LEFT JOIN pinjam"+
            " as b on a.code = b.code_books";
            databaseConnection.query(qry,(err,result)=>{
                  res.send(result);  
            });
    }catch(e){
        res.send('can not get books list');
        console.log('can not get books list');
    }
});
router.get('/returns', async function(req,res,next){
   const qry = "SELECT * FROM pinjam where code_books='"+req.body.code_book+"'";
   const check_pinjam = await new Promise((resove)=>{ 
        databaseConnection.query(qry,(err,result)=>{
          if(err) throw err;
          resove(result);
        });
  }).then(temp=>{
    return temp;
  });
   const date_db = new Date(check_pinjam[0].date);
   const predic = new Date(date_db.getTime()+7*24*60*60*1000);
   //const hasil = dateFormat.format(predic,"DD/MM/YYYY");
   const new_date = new Date();
   //const hasil2 = dateFormat.format(new_date,"DD/MM/YYYY");
   if(predic < new_date){
      const penalty = new Date(new_date.getTime()+3*24*60*60*1000);
      const qry1 = "UPDATE pinjam set ? where code_books='"+req.body.code_book+"'";
      const value = {date:null,date_penalty:penalty ,status:2};
      databaseConnection.query(qry1,[value],(err,result)=>{
        if(err) throw err;
        res.send('you have penalty 3 day until date '+penalty+' can not borrow any books');
      });
   }else{
      const qry2 = "DELETE FROM pinjam where code_books='"+req.body.code_book+"'";
      databaseConnection.query(qry2,(err,result)=>{
        if(err) throw err;
        res.send('you has been return book with code '+ req.body.code_book);
      });
   }  
  
});
module.exports = router;